<?php /* D:\xampp\htdocs\Chat\resources\views/welcome.blade.php */ ?>
<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title>Test Sending Data From Restfull api</title>
 <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Estate Register Form a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //Meta-Tags -->
    
    <!-- css files -->
    <link href="<?php echo e(asset('css/css/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css" media="all">
    <link href="<?php echo e(asset('css/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all"/>
    <!-- //css files -->
    
    <!-- google fonts -->
    <link href="//fonts.googleapis.com/css?family=Raleway:400,500,600,700,800,900" rel="stylesheet">
    <!-- //google fonts -->
    
</head>
<body>

<div class="signupform">
    <h1>Sending Data RestFull api</h1>
        <div class="container">
            <!-- main content -->
            <div class="agile_info">
                <div class="w3l_form">
                    <div class="left_grid_info">
                        <img src="<?php echo e(asset('css/images/left.png')); ?>" alt="" />
                    </div>
                </div>
                <div class="w3_info">
                    <h2>Web Client to Web Services</h2>
                    <p>Vestibulum est nulla, fermentum eget ipsum euismod et, tincidunt at dui dolor sit.</p>
                        <form action="<?php echo e(url('api/store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="input-group">
                                <span><i class="fa fa-user" aria-hidden="true"></i></span>
                                <input type="text"  name="username" placeholder="username" required=""> 
                            </div>
                            <div class="input-group">
                                <span><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                <input type="email" name="email" placeholder="email" required=""> 
                            </div>
                            <div class="input-group">
                                <span><i class="" aria-hidden="true"></i></span>
                                <input type="file" name="image" placeholder="image" required="">
                            </div>       
                                <button class="btn btn-danger btn-block" type="submit">Sign Up</button >                
                        </form>
                    <p class="account">Already have an account? <a href="#">Login</a></p>
                </div>
            </div>
            <!-- //main content -->
        </div>
        <!-- footer -->
        <div class="footer">
            <p>&copy; 2018 Estate Register form. All Rights Reserved | Design by <a href="https://w3layouts.com/" target="blank">W3layouts</a></p>
        </div>
        <!-- footer -->
</div>
    
</body>
</html>