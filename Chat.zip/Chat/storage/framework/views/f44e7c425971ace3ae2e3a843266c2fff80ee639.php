<?php /* D:\xampp\htdocs\Chat\resources\views/home.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th>Nomor</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Image</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
            <?php $__currentLoopData = $servis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <th scope="row"><?php echo e($sr->id); ?></th>
                  <td><?php echo e($sr->username); ?></td>
                  <td><?php echo e($sr->email); ?></td>
                  <td> <img src="<?php echo e(asset($sr->image)); ?> " style="height: 20%; width: 30%;"> </td>
                  <td> <?php echo e($sr->note); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>