@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <table class="table">
              <thead class="thead-dark">
                <tr>
                  <th>Nomor</th>
                  <th>Username</th>
                  <th>Email</th>
                  <th>Image</th>
                  <th>Note</th>
                </tr>
              </thead>
              <tbody>
            @foreach($servis as $sr)
                <tr>
                  <th scope="row">{{ $sr->id }}</th>
                  <td>{{ $sr->username }}</td>
                  <td>{{ $sr->email }}</td>
                  <td> <img src="{{ asset($sr->image) }} " style="height: 20%; width: 30%;"> </td>
                  <td> {{ $sr->note }}</td>
                </tr>
            @endforeach
              </tbody>
            </table>
        </div>
    </div>
</div>
@endsection
