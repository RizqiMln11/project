<?php

use Faker\Generator as Faker;

$factory->define(App\service::class, function (Faker $faker) {
    return [
        //
    ];
});
